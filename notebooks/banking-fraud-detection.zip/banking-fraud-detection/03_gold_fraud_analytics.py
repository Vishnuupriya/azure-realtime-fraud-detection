# Databricks notebook source
# MAGIC %md
# MAGIC # Gold Layer — Banking Fraud Analytics
# MAGIC
# MAGIC Aggregate validated Silver transactions into business-ready metrics.
# MAGIC
# MAGIC **Metrics**
# MAGIC - Total transactions
# MAGIC - Total transaction amount
# MAGIC - Fraudulent transaction count
# MAGIC - Fraud rate percentage
# MAGIC
# MAGIC **Grouping:** Merchant and transaction type  
# MAGIC **Input:** Silver Delta  
# MAGIC **Output:** Gold Delta

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define silver_path in Cell 2

# COMMAND ----------

silver_path = (
    "abfss://silver@stbankingfrauddetection.dfs.core.windows.net/"
    "banking_transactions/"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Define Gold paths and aggregation

# COMMAND ----------

from pyspark.sql.functions import (
    col, count, sum as spark_sum,
    when, round as spark_round
)

gold_path = (
    "abfss://gold@stbankingfrauddetection.dfs.core.windows.net/"
    "fraud_analytics/"
)

gold_checkpoint = (
    "abfss://gold@stbankingfrauddetection.dfs.core.windows.net/"
    "checkpoints/gold_analytics_v1/"
)

silver_stream = (
    spark.readStream
    .format("delta")
    .load(silver_path)
)

gold_aggregated = (
    silver_stream
    .groupBy("merchant", "transaction_type")
    .agg(
        count("*").alias("total_transactions"),
        spark_sum("amount").alias("total_amount"),
        spark_sum(
            when(col("is_fraud") == True, 1).otherwise(0)
        ).alias("fraud_count")
    )
    .withColumn(
        "fraud_rate_pct",
        spark_round(
            col("fraud_count") / col("total_transactions") * 100,
            2
        )
    )
)

print("Gold aggregation configured.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Start Gold streaming

# COMMAND ----------

gold_query = (
    gold_aggregated.writeStream
    .outputMode("complete")
    .format("delta")
    .option("path", gold_path)
    .option("checkpointLocation", gold_checkpoint)
    .start()
)

print("Gold analytics stream started.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Expected output

# COMMAND ----------

display(
    spark.read
    .format("delta")
    .load(gold_path)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipeline Validation — Gold Streaming Status
# MAGIC
# MAGIC Verify that the Gold streaming query is active and has no recorded exception.

# COMMAND ----------

print("Gold active:", gold_query.isActive)
print("Gold status:", gold_query.status)
print("Gold exception:", gold_query.exception())

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold Layer — Final Data Validation
# MAGIC
# MAGIC Validate the aggregated Gold Delta dataset before connecting it to Power BI.

# COMMAND ----------

gold_df = (
    spark.read
    .format("delta")
    .load(gold_path)
)

print("Gold row count:", gold_df.count())
gold_df.printSchema()

display(gold_df.orderBy("merchant", "transaction_type"))

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold Layer — Power BI Export
# MAGIC
# MAGIC Export the aggregated Gold fraud analytics to a single CSV file for dashboard development.
# MAGIC
# MAGIC **Source:** Gold Delta table  
# MAGIC **Destination:** Gold container in ADLS Gen2  
# MAGIC **Format:** CSV with header

# COMMAND ----------

powerbi_export_path = (
    "abfss://gold@stbankingfrauddetection.dfs.core.windows.net/"
    "powerbi_export/"
)

(
    gold_df.coalesce(1)
    .write
    .mode("overwrite")
    .option("header", "true")
    .csv(powerbi_export_path)
)

print("Gold CSV export completed.")