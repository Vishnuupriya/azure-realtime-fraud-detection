# Databricks notebook source
# MAGIC %md
# MAGIC # 1. Configure Event Hubs Connection
# MAGIC
# MAGIC Retrieve the Event Hubs connection string from the Databricks secret scope and configure Spark's Kafka source.
# MAGIC
# MAGIC - Secret scope: `banking-fraud-detect`
# MAGIC - Secret key: `event-hubs-connection-string`
# MAGIC - Event Hub: `banking-transactions`
# MAGIC - Namespace: `ehns-realtime-banking-fraud-detection`
# MAGIC
# MAGIC The connection string is retrieved from Databricks Secrets and must never be printed or committed to source control.

# COMMAND ----------

connection_string = dbutils.secrets.get(
    scope="banking-fraud-detect",
    key="event-hubs-connection-string"
)

print("Event Hubs secret retrieved successfully.")

# COMMAND ----------

# MAGIC %md
# MAGIC # 2. Test Event Hubs Connectivity
# MAGIC
# MAGIC This diagnostic reads events from the Event Hubs Kafka endpoint and writes them to the notebook console.
# MAGIC
# MAGIC Use it when troubleshooting connectivity. It is not the production ingestion query. Because the source uses `startingOffsets = latest`, it reads newly arriving events rather than replaying all earlier events

# COMMAND ----------

connection_string = dbutils.secrets.get(
    scope="banking-fraud-detect",
    key="event-hubs-connection-string"
).strip()

namespace = "ehns-realtime-banking-fraud-detection.servicebus.windows.net"

kafka_options = {
    "kafka.bootstrap.servers": f"{namespace}:9093",
    "subscribe": "banking-transactions",
    "startingOffsets": "latest",
    "kafka.security.protocol": "SASL_SSL",
    "kafka.sasl.mechanism": "PLAIN",
    "kafka.sasl.jaas.config": (
        'kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required '
        'username="$ConnectionString" '
        f'password="{connection_string}";'
    )
}

print("Kafka configuration refreshed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### verify the Event Hubs connection before starting the stream.
# MAGIC ### Test Kafka connectivity

# COMMAND ----------

connection_string = dbutils.secrets.get(
    scope="banking-fraud-detect",
    key="event-hubs-connection-string"
).strip()

print("Starts with Endpoint=sb://:", connection_string.startswith("Endpoint=sb://"))
print("Contains SharedAccessKeyName:", "SharedAccessKeyName=" in connection_string)
print("Contains SharedAccessKey:", "SharedAccessKey=" in connection_string)
print("Contains EntityPath:", "EntityPath=" in connection_string)

# COMMAND ----------

connection_string = dbutils.secrets.get(
    scope="banking-fraud-detect",
    key="event-hubs-connection-string"
).strip()

print("Endpoint:", connection_string.startswith("Endpoint=sb://"))
print("Key name:", "SharedAccessKeyName=" in connection_string)
print("Key value present:", "SharedAccessKey=" in connection_string)

# COMMAND ----------

# MAGIC %md
# MAGIC # 3. Inspect Incoming Events
# MAGIC
# MAGIC Display the event payload as a string along with its Kafka timestamp.
# MAGIC
# MAGIC Use this cell to confirm that transactions are arriving and to inspect the raw JSON. Stop the preview query when you no longer need it, and avoid running unnecessary streaming queries alongside the Bronze ingestion query.

# COMMAND ----------

test_stream = (
    spark.readStream
    .format("kafka")
    .options(**kafka_options)
    .option("startingOffsets", "latest")
    .option("failOnDataLoss", "false")
    .load()
)

query = (
    test_stream.writeStream
    .format("console")
    .option(
        "checkpointLocation",
        "abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/checkpoints/eventhub_connectivity_test_v3/"
    )
    .trigger(availableNow=True)
    .start()
)

query.awaitTermination()

# COMMAND ----------

from pyspark.sql.functions import col

inspect_stream = (
    test_stream
    .select(
        col("value").cast("string").alias("transaction_json"),
        col("timestamp").alias("event_timestamp")
    )
)

display(
    inspect_stream,
    checkpointLocation="abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/checkpoints/eventhub_inspect_v3/"
)

# COMMAND ----------

# MAGIC %md
# MAGIC # 4. Bronze Layer — Raw Event Ingestion
# MAGIC
# MAGIC Read transaction events from Azure Event Hubs and append them to a Delta dataset in the ADLS Gen2 `bronze` container.
# MAGIC
# MAGIC The Bronze dataset preserves:
# MAGIC - Raw transaction JSON
# MAGIC - Kafka topic, partition, and offset
# MAGIC - Kafka event timestamp
# MAGIC - Databricks ingestion timestamp
# MAGIC
# MAGIC A dedicated checkpoint path stores streaming progress so the query can recover after a restart. Keep the stream running while the Python transaction producer is sending events.

# COMMAND ----------

from pyspark.sql.functions import col, current_timestamp

bronze_path = (
    "abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/"
    "banking_transactions/"
)

checkpoint_path = (
    "abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/"
    "checkpoints/bronze_ingestion_v1/"
)

bronze_df = test_stream.select(
    col("value").cast("string").alias("transaction_json"),
    col("topic"),
    col("partition"),
    col("offset"),
    col("timestamp").alias("kafka_timestamp"),
    current_timestamp().alias("ingestion_timestamp")
)

bronze_query = (
    bronze_df.writeStream
    .format("delta")
    .outputMode("append")
    .option("path", bronze_path)
    .option("checkpointLocation", checkpoint_path)
    .start()
)

print("Bronze ingestion stream started.")

# COMMAND ----------

# MAGIC %md
# MAGIC # 5. Verify Bronze Delta Data
# MAGIC
# MAGIC Read the Bronze Delta dataset from ADLS Gen2 and display a small sample to confirm that events have been persisted.
# MAGIC
# MAGIC Run this after the Bronze ingestion query has written data. This is a batch read for verification; it does not start another streaming query.

# COMMAND ----------

display(
    spark.read.format("delta")
    .load("abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/banking_transactions/")
    .limit(10)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # 6. Stop Bronze Ingestion (Run Only When Needed)
# MAGIC
# MAGIC Run the following control cell only when you intentionally want to stop the active Bronze streaming query.
# MAGIC
# MAGIC Stopping this query pauses ingestion. It does not delete the Bronze Delta data or checkpoint files.

# COMMAND ----------

bronze_query.stop()

# COMMAND ----------

# MAGIC %md
# MAGIC # 7. Inspect Raw JSON Before Silver Transformation
# MAGIC
# MAGIC Display a small sample of the raw transaction JSON stored in Bronze. Use the actual field names and data types in this output to define the Silver schema.
# MAGIC
# MAGIC This is a one-time inspection step; it does not transform or modify the Bronze data.

# COMMAND ----------

display(
    spark.read.format("delta")
    .load("abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/banking_transactions/")
    .select("transaction_json")
    .limit(5)
)

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC