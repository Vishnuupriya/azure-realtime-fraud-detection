# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Layer — Clean and Transform Transactions
# MAGIC
# MAGIC Transform raw banking transaction events from the Bronze Delta layer into structured, validated records.
# MAGIC
# MAGIC **Processing steps**
# MAGIC - Parse the raw transaction JSON using an explicit schema.
# MAGIC - Convert the amount and timestamp into appropriate data types.
# MAGIC - Remove records missing required fields.
# MAGIC - Deduplicate transactions using `transaction_id` with a 10-minute event-time watermark.
# MAGIC - Write clean records to the Silver Delta layer in ADLS Gen2.
# MAGIC
# MAGIC **Input:** Bronze Delta data  
# MAGIC **Output:** Silver Delta data  
# MAGIC **Storage:** Azure Data Lake Storage Gen2

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Layer — Storage Access Validation
# MAGIC
# MAGIC Verify that the Silver container is accessible before starting the transformation stream.

# COMMAND ----------

silver_path = (
    "abfss://silver@stbankingfrauddetection.dfs.core.windows.net/"
    "banking_transactions/"
)

display(
    dbutils.fs.ls(
        "abfss://silver@stbankingfrauddetection.dfs.core.windows.net/"
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Read and transform Bronze data

# COMMAND ----------

from pyspark.sql.functions import (
    col, from_json, to_timestamp, current_timestamp
)
from pyspark.sql.types import (
    StructType, StructField, StringType,
    DoubleType, BooleanType
)

# Bronze and Silver paths
bronze_path = (
    "abfss://bronze@stbankingfrauddetection.dfs.core.windows.net/"
    "banking_transactions/"
)

silver_path = (
    "abfss://silver@stbankingfrauddetection.dfs.core.windows.net/"
    "banking_transactions/"
)

silver_checkpoint = (
    "abfss://silver@stbankingfrauddetection.dfs.core.windows.net/"
    "checkpoints/silver_transformation_v1/"
)

# Define the expected transaction JSON schema
transaction_schema = StructType([
    StructField("transaction_id", StringType(), True),
    StructField("account_id", StringType(), True),
    StructField("amount", DoubleType(), True),
    StructField("merchant", StringType(), True),
    StructField("location", StringType(), True),
    StructField("transaction_timestamp", StringType(), True),
    StructField("device_id", StringType(), True),
    StructField("is_fraud", BooleanType(), True),
    StructField("transaction_type", StringType(), True)
])

# Read the Bronze Delta stream
bronze_stream = (
    spark.readStream
    .format("delta")
    .load(bronze_path)
)

# Parse raw JSON into structured columns
parsed_stream = (
    bronze_stream
    .withColumn(
        "transaction",
        from_json(col("transaction_json"), transaction_schema)
    )
    .select(
        "topic",
        "partition",
        "offset",
        "kafka_timestamp",
        "ingestion_timestamp",
        col("transaction.transaction_id").alias("transaction_id"),
        col("transaction.account_id").alias("account_id"),
        col("transaction.amount").alias("amount"),
        col("transaction.merchant").alias("merchant"),
        col("transaction.location").alias("location"),
       to_timestamp(
        col("transaction.transaction_timestamp")).alias("transaction_timestamp"),
        col("transaction.device_id").alias("device_id"),
        col("transaction.is_fraud").alias("is_fraud"),
        col("transaction.transaction_type").alias("transaction_type")
    )
)

# Keep records with required fields and valid amount
clean_stream = (
    parsed_stream
    .filter(
        col("transaction_id").isNotNull()
        & col("account_id").isNotNull()
        & col("amount").isNotNull()
        & (col("amount") > 0)
        & col("transaction_timestamp").isNotNull()
    )
    .withWatermark("transaction_timestamp", "10 minutes")
    .dropDuplicates(["transaction_id"])
    .withColumn("silver_processed_at", current_timestamp())
)

print("Silver transformation is configured.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Write the Silver stream

# COMMAND ----------

silver_query = (
    clean_stream.writeStream
    .format("delta")
    .outputMode("append")
    .option("path", silver_path)
    .option("checkpointLocation", silver_checkpoint)
    .start()
)

print("Silver transformation stream started.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Expected output

# COMMAND ----------

display(
    spark.read.format("delta")
    .load(silver_path)
    .limit(10)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Layer — Validate Bronze JSON Schema
# MAGIC
# MAGIC Inspect raw transaction events from Bronze and verify that the transaction JSON matches the expected Silver schema before filtering records.

# COMMAND ----------

from pyspark.sql.functions import col, from_json

# Read a small batch from Bronze
bronze_batch = (
    spark.read
    .format("delta")
    .load(bronze_path)
)

# Inspect raw JSON records
display(
    bronze_batch
    .select("transaction_json")
    .limit(5)
)

# Test parsing against the existing transaction schema
parsed_test = bronze_batch.select(
    col("transaction_json"),
    from_json(
        col("transaction_json"),
        transaction_schema
    ).alias("parsed")
)

display(
    parsed_test
    .select(
        "transaction_json",
        "parsed.*"
    )
    .limit(5)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Diagnose Transaction Timestamp
# MAGIC
# MAGIC Inspect a raw transaction event to identify the timestamp field name and format before updating the Silver schema.

# COMMAND ----------

display(
    bronze_batch
    .select("transaction_json")
    .limit(1)
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Gold Layer — Prepare Fraud Analytics
# MAGIC
# MAGIC Inspect the Silver Delta table to identify the available transaction fields and data types before creating business-level aggregations.
# MAGIC
# MAGIC **Input:** Silver Delta Lake
# MAGIC **Output:** Schema and sample records for Gold design

# COMMAND ----------

# MAGIC %md
# MAGIC ### Check schema

# COMMAND ----------

silver_df = (
    spark.read
    .format("delta")
    .load(silver_path)
)

silver_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC ### View sample records

# COMMAND ----------

display(silver_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC