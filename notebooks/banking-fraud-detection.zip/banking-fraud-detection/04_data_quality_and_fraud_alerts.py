# Databricks notebook source
# MAGIC %md
# MAGIC #  Automated Data Quality and Fraud Alerts
# MAGIC
# MAGIC Validate Silver transactions for missing IDs, invalid amounts,
# MAGIC invalid timestamps, and duplicate transaction IDs.
# MAGIC
# MAGIC Generate alerts for transactions flagged as fraudulent or
# MAGIC classified as HIGH_VALUE or UNUSUAL_LOCATION.
# MAGIC
# MAGIC Input: Silver Delta
# MAGIC Output: Quality summary and fraud alerts# Automated Data Quality and Fraud Alerts
# MAGIC
# MAGIC Validate Silver transactions for missing IDs, invalid amounts,
# MAGIC invalid timestamps, and duplicate transaction IDs.
# MAGIC
# MAGIC Generate alerts for transactions flagged as fraudulent or
# MAGIC classified as HIGH_VALUE or UNUSUAL_LOCATION.
# MAGIC
# MAGIC Input: Silver Delta
# MAGIC Output: Quality summary and fraud alertsmated Data Quality and Fraud Alerts
# MAGIC
# MAGIC Validate Silver transactions for missing IDs, invalid amounts,
# MAGIC invalid timestamps, and duplicate transaction IDs.
# MAGIC
# MAGIC Generate alerts for transactions flagged as fraudulent or
# MAGIC classified as HIGH_VALUE or UNUSUAL_LOCATION.
# MAGIC
# MAGIC Input: Silver Delta
# MAGIC Output: Quality summary and fraud alerts

# COMMAND ----------

# MAGIC %md
# MAGIC ### Python: Data-quality checks

# COMMAND ----------

from pyspark.sql.functions import (
    col, count, sum as spark_sum, when
)

silver_path = (
    "abfss://silver@stbankingfrauddetection.dfs.core.windows.net/"
    "banking_transactions/"
)

silver_df = spark.read.format("delta").load(silver_path)

checks = silver_df.agg(
    count("*").alias("total_records"),
    spark_sum(
        when(col("transaction_id").isNull(), 1).otherwise(0)
    ).alias("missing_transaction_id"),
    spark_sum(
        when(col("account_id").isNull(), 1).otherwise(0)
    ).alias("missing_account_id"),
    spark_sum(
        when(col("amount").isNull() | (col("amount") <= 0), 1)
        .otherwise(0)
    ).alias("invalid_amount"),
    spark_sum(
        when(col("transaction_timestamp").isNull(), 1).otherwise(0)
    ).alias("invalid_timestamp")
)

display(checks)

print("Data-quality checks completed.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Python: Generate fraud alerts

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

alerts_path = (
    "abfss://gold@stbankingfrauddetection.dfs.core.windows.net/"
    "fraud_alerts/"
)

fraud_alerts = (
    silver_df
    .filter(
        (col("is_fraud") == True)
        | col("transaction_type").isin(
            "HIGH_VALUE", "UNUSUAL_LOCATION"
        )
    )
    .select(
        "transaction_id",
        "account_id",
        "amount",
        "merchant",
        "location",
        "transaction_type",
        "is_fraud"
    )
    .withColumn("alert_generated_at", current_timestamp())
)

display(fraud_alerts.limit(20))

print("Fraud alerts generated:", fraud_alerts.count())

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Save the alerts

# COMMAND ----------

(
    fraud_alerts.write
    .format("delta")
    .mode("overwrite")
    .save(alerts_path)
)

print("Fraud alerts saved to ADLS Gen2.")